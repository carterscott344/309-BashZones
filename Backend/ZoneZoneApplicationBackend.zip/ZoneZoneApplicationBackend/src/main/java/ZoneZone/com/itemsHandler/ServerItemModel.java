package ZoneZone.com.itemsHandler;

import jakarta.persistence.*;

@Entity
@Table(name = "server_items")
public class ServerItemModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // ✅ Ensures only one AUTO_INCREMENT key
    private Long serverItemID;

    private Long ownerAccountID;
    private String serverItemName;
    private String serverItemDescription;
    private String itemCost;
    

}
